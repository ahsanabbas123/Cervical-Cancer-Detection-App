package com.example.myapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;


public class patientRegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText patientName;
    private EditText patientGender;
    private EditText patientAge;
    private EditText patientRemarks;

    private Button buttonRegisterPatient;

    private String name;
    private String gender;
    private String age;
    private String remarks;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_register);

        patientName = findViewById(R.id.patientName);
        patientGender = findViewById(R.id.patientGender);
        patientAge = findViewById(R.id.patientAge);
        patientRemarks = findViewById(R.id.patientRemarks);
        buttonRegisterPatient = findViewById(R.id.buttonRegisterPatient);

        buttonRegisterPatient.setOnClickListener(patientRegisterActivity.this);

    }

    @Override
    public void onClick(View view) {

        if (view == buttonRegisterPatient) {
            registerPatient();
        }

    }

    @IgnoreExtraProperties
    public class Patient {

        private String uid;
        private String name;
        private String gender;
        private String age;
        private String remarks;

        public Patient() {}

        public Patient(String uid, String name, String gender, String age, String remarks) {
            this.uid = uid;
            this.name = name;
            this.gender = gender;
            this.age = age;
            this.remarks = remarks;
        }

        @Exclude
        public Map<String, Object> toMap() {

            HashMap<String, Object> result = new HashMap<>();

            result.put("uid", uid);
            result.put("name", name);
            result.put("gender", gender);
            result.put("age", age);
            result.put("remarks", remarks);

            return result;
        }
    }

    private void registerPatient() {

        name = patientName.getText().toString().trim();
        gender = patientGender.getText().toString().trim();
        age = patientAge.getText().toString().trim();
        remarks = patientRemarks.getText().toString().trim();


        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Patient patient = new Patient(uid, name, gender, age, remarks);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference mDatabase = database.getReference();


        String key = mDatabase.child("patients").push().getKey();
        Map<String, Object> patientValues = patient.toMap();

        Map<String, Object> childUpdates = new HashMap<>();
        DatabaseReference updateUsers = database.getReference("users/" + uid);
//        childUpdates.put("/users/"+uid, key);
        childUpdates.put("/patients/"+key, patientValues);
        mDatabase.updateChildren(childUpdates);
        Map<String, Object> userAddPatient = new HashMap<>();
        userAddPatient.put(key, patientValues);
        updateUsers.updateChildren(userAddPatient);
        Toast.makeText(patientRegisterActivity.this, "Adding data to db",Toast.LENGTH_LONG).show();


    }

}
